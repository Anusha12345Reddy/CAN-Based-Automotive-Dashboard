/* 
 * File:   ecu2_main.h
 * Author: ANUSHA
 *
 * Created on 15 May, 2025, 10:16 AM
 */

#ifndef ECU2_MAIN_H
#define	ECU2_MAIN_H

#include <xc.h>

#define _XTAL_FREQ 20000000

/* Defines the data */
#define TRUE			1
#define FALSE			0


#endif	/* ECU2_MAIN_H */

